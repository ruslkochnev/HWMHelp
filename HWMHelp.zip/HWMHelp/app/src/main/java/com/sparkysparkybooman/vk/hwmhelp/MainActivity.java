package com.sparkysparkybooman.vk.hwmhelp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.webkit.WebView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(getApplicationContext(),
                "ca-app-pub-6978053805119593/1424709345");
        mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        WebView wb = (WebView)findViewById(R.id.wb);
        wb.loadUrl(getString(R.string.page_about));
        wb.setBackgroundColor(getResources().getColor(R.color.background_my));
        wb.getSettings().setUseWideViewPort(true);
        wb.getSettings().setLoadWithOverviewMode(true);


       // nav_about = (Button)findViewById(R.id.nav_about);
        //nav_faq = (Button)findViewById(R.id.nav_faq);
      //  nav_yours_help = (Button)findViewById(R.id.nav_yours_help);

    //    nav_about.setOnClickListener(this);
  //      nav_faq.setOnClickListener(this);
//        nav_yours_help.setOnClickListener(this);



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);






    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        WebView wb = (WebView)findViewById(R.id.wb);
        wb.setBackgroundColor(getResources().getColor(R.color.background_my));
        wb.getSettings().setUseWideViewPort(true);
        wb.getSettings().setLoadWithOverviewMode(true);


  //      if (id == R.id.nav_about) {
  //          tv2.setText(Html.fromHtml(getResources().getString(R.string.page_about)));
 //           tv2.setMovementMethod(LinkMovementMethod.getInstance());
 //       } else if (id == R.id.nav_yours_help) {
 //           tv2.setText(R.string.nav_about);

  //      } else if (id == R.id.nav_faq) {
     //



   //     } else if (id == R.id.nav_traffic) {




   //     }

        switch (id) {
            case R.id.nav_about:
                wb.loadUrl(getString(R.string.page_about));
                wb.getSettings().setUseWideViewPort(true);
                wb.getSettings().setLoadWithOverviewMode(true);

                break;
            case R.id.nav_yours_help:
                wb.loadUrl(getString(R.string.your_help_html));
                wb.getSettings().setUseWideViewPort(true);
                wb.getSettings().setLoadWithOverviewMode(true);

                break;
            case R.id.nav_faq:


                break;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    public void OnClickNavHeader(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.heroeswm.ru/?rid=692098"));
        startActivity(browserIntent);
    }
}
